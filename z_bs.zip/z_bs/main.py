import z_bs.ui as bsUI
from importlib import reload
reload(bsUI)
widget, toolWidget = bsUI.openShapeEditor()
